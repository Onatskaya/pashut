<?php
include_once('functions/function.php');
print_r($_POST);
die;
?>