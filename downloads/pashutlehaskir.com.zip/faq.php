<?php

include_once('functions/function.php');
?>
	
	
    
    <!DOCTYPE HTML> 
<html lang="en">
  <head>

  	
 
		
				<title>pashutlehaskir.com</title>
				<link rel="shortcut icon" href="#" />
				<meta charset="utf-8">
				<meta http-equiv="X-UA-Compatible" content="IE=edge">
				
				<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, width=device-width">
				<meta http-equiv="expires" content="0" />
				<meta http-equiv="Pragma" content="no-cache" />
				<meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8" />

				
       			<meta name="apple-itunes-app" content="app-id=509021914">
   					<script type="text/javascript">
setTimeout(function(){var a=document.createElement("script");
var b=document.getElementsByTagName("script")[0];
a.src=document.location.protocol+"//script.crazyegg.com/pages/scripts/0044/7420.js?"+Math.floor(new Date().getTime()/3600000);
a.async=true;a.type="text/javascript";b.parentNode.insertBefore(a,b)}, 1);
</script>

<script>
var _prum = [['id', '56a93ecdabe53ddd5a18ddad'],
             ['mark', 'firstbyte', (new Date()).getTime()]];
(function() {
    var s = document.getElementsByTagName('script')[0]
      , p = document.createElement('script');
    p.async = 'async';
    p.src = '//rum-static.pingdom.net/prum.min.js';
    s.parentNode.insertBefore(p, s);
})();
</script> 

			<script type="text/javascript">
			function movetoNext(current, nextFieldID) {
			if (current.value.length >= current.maxLength) {
			document.getElementById(nextFieldID).focus();
			}
			}
			</script>
			 <!-- Google Fonts embed code -->
			<script type="text/javascript">
				(function() {
					var link_element = document.createElement("link"),
						s = document.getElementsByTagName("script")[0];
					if (window.location.protocol !== "http:" && window.location.protocol !== "https:") {
						link_element.href = "http:";
					}
					link_element.href += "//fonts.googleapis.com/css?family=Lato:100italic,100,300italic,300,400italic,400,700italic,700,900italic,900";
					link_element.rel = "stylesheet";
					link_element.type = "text/css";
					s.parentNode.insertBefore(link_element, s);
				})();
			</script>


				
				<!-- Latest compiled and minified CSS -->
				<link href="css/201603/ui-lightness/jquery-ui-1.10.4.css" rel="stylesheet">
				<link rel="stylesheet" href="css/bootstrap.min.css">
				<!-- Custom styles for this template -->
				<link href="css/201603/global.css" rel="stylesheet">
				<link href="css/201603/section.css" rel="stylesheet">
				<link href="css/201603/carousel.css" rel="stylesheet">
			
					<meta name="keywords" content="pashutlehaskir.com | Rent SoCal Houses, Apartments & More, Los Angeles rentals, Santa Monica House, South Bay Rentals, Los Angeles Apartments, Orange County Rentals, San Diego Apartments, Hermosa Beach Apartments, Hollywood For Rent, Burbank Apartments, Glendale Homes, Studio City Rentals, Apartments for Rent, Houses for Rent, Condos for Rent, Apartments in Los Angeles, Apartments in LA, USC, University of Southern California, Cal State, California State University, UCLA, University of California, University of California Los Angeles, Loyola Marymount University, Pepperdine, Pepperdine University, USC Student Housing, USC Housing, USC Apartments, Cal State Housing, Cal State Student Housing, Cal State Apartments, UCLA Housing, UCLA Student Housing, UCLA Apartments, LMU Housing, LMU Student Housing, LMU Apartments, Pepperdine Housing, Pepperdine Student Housing, Pepperdine Apartments" />
				
					<meta name="description" content="pashutlehaskir.com is the #1 home finding service in the Los Angeles area. Search SoCal apartment rentals, houses, condos & roommates!" />
				
					<meta name="robots" content="index,follow" />
					<meta name="GOOGLEBOT" content="index,follow" />
				
			
			
			<meta name="google-translate-customization" content="954d153704cc37f5-fac58c9bb4d3c842-g115d03cfb1ac5d23-17"></meta>
			
			
        
	</head>

	
	<body  class="guest" >
	
	
		
		<div id="slidedown-content" data-status="hide" class="none">
			<div id="login-content" class="fb">
				<form action="login/login.html" name="loginForm" method="post">
					<span>
						<label>Username</label> 
						<input type="text" name="username" class="text" size="10" maxlength="100" />
					</span>
					<span>
						<label>Password</label>
						<input type="password" autocomplete="off" class="text" name="password" size="10" maxlength="45" />
					</span>	

					
					<input type="image" name="login" class="submit" src="images/new/btn-login.png" align="absmiddle" />
					
					

				</form>
				<div class="separator">
				-------------- OR --------------
				</div>
				<div class="fb-login-section">
				<a href="#" class="fb-login"><img src="images/fblogin.png"></a>
				</div>
			</div>		
		</div>
	
		<?php
		include('header.php');
		?>
	
	
    <!-- Carousel
    ================================================== -->
	<div class="container faq">

<div class="oneColumnLayout static-page">
	
	<div class="col-md-12">
	 

<h2>
How do I join?
</h2>
Simply click "Join Now", select the membership plan suitable to your needs and enter the required
information. Property Owners can list their properties for free, daily.
<br/>


<h2>
Are all listings on PL accurate and available to rent?
</h2>
Yes! All live listings are updated in real time. Each listing, includes pre-approved photos/videos and
property specifications go through a verification process for accuracy.
<br/>

<h2>
How do I schedule a viewing or showing of a property I like?
</h2>
Each individual property listing will have the option to set a viewing time directly on the property
page. Property owners set specific times to allow both parties convenience and quick access to the
property. Confirmation emails are sent to both parties during an Instant Viewing request.

<h2>
How much does it cost to join?
</h2>
Single monthly memberships for renters costs 99NIS for 30 days and receive unlimited access to all
listings and includes additional comprehensive resources and moving solutions. Other membership
plans are also available to better match your needs.
<br/>

<h2>Can I cancel my membership if I find a property before my monthly membership expires?</h2>
No. All memberships are given access to property information for 30 days.
<br/>

<h2>
What happens when I rent the property?
</h2>
Congratulations! If you search, find and rent an available property through PashutLeHaskir, a onetime
25% service fee of the monthly rent amount is charged to your account. There are no other fees
associated with PL other than membership fees and and a one time service fee.
<br/>

<h2>
What happens if I schedule an "Instant Viewing Time" and
the Owner or Current Tenants are not at the property?
</h2>
PashutLehaskir.com cannot guarentee the availability of Instant Viewing times set by property
owners. However, we work closely with Owners to ensure viewing times are accurate and each
listing also includes direct contact information to the owner.
<br/>


<h2>FAQ – Owners</h2>


<h2>
How do I list my property?
</h2>
Property Owners can list a property or properties for free. Simply click Post Listing or Add Property
to become a member. Properties listed by owners are saved and can be relisted for covenience.
<br/>

<h2>
Where can renters find my property?
</h2>
All listings are organized by location and date and appear on our main listings page until the
property is rented.
<br/>

<h2>What do I need to list my property?</h2>
Property Owners are required to provide a minimum of 5 clear, accurate photos of each room,
bedroom, bathroom and balcony spaces and 1 clear photo of the building from the outside. A
minimum of 6 photos is required to list your property as well as providing accurate property
specifications, size, scheduling times and contact information for potential renters.
<br>
<h2>Who sees my property on PashutLehaskir?</h2>
All members of PL have access to each property you list.
<br>
<h2>If I rent out my property, is my property still listed on PL?</h2>
Congratulations! Once your property is taken by a renter, simply click the “Rented” button on the
bottom of your property page to remove your listing.<span style="color:red;font-weight:bold;"> Renting your property on
PashutLehaskir.com entitles you to a one-time 12.5% credit of the amount your property is
listed for. Property Owners that list with PashutLeHaskir create an income with each
property listed!</span>

	
		
	</div>
</div>

</div> <!-- End main container div -->
	
	
		<!-- FOOTER -->
		<?php
			include('footer.php');
		?>
		
		
	
	
	<!-- Bootstrap core JavaScript
	================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery.min.js"></script>
	

	
	<script src="js/new/jquery-ui-1.10.4/jquery-ui-1.10.4.js"></script>
	<script src="js/new/jquery.cycle.all.js"></script>
	
	<!-- Latest compiled and minified JavaScript -->
	<script src="js/bootstrap.min.js"></script>
	
	
			
	<script src="js/fb_login.js"></script>	
	<script src="js/navigation/menu.js" type="text/javascript" language="javascript"></script>	
	<script src="js/default.js" type="text/javascript" language="javascript"></script>	

	<script src="js/ddaaccordion.js" type="text/javascript" language="javascript"></script>


	
	<!-- Default JavaScript -->
	<script src="js/new/default.js"></script>
	
	
	<!-- Pretty photo --->
	<link rel="stylesheet" href="../js/new/prettyphoto/css/prettyPhoto.css" type="text/css" media="screen" charset="utf-8" />
	<script src="../js/new/prettyphoto/js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>
	
	
	<script src="../js/tooltips/wz_tooltip.js" type="text/javascript" language="javascript"></script>
			
			
				


		
	<div id="ttdUniversalPixelTagfb79dc7af6cc4733a9c4a87c68c6f55e" style="display:none">
	        <script src="https://js.adsrvr.org/up_loader.1.1.0.js" type="text/javascript"></script>
	        <script type="text/javascript">
	            (function(global) {
	                if (typeof TTDUniversalPixelApi === 'function') {
	                    var universalPixelApi = new TTDUniversalPixelApi();
	                    universalPixelApi.init("nalbr2d", ["k56d7yb"], "https://insight.adsrvr.org/track/up", "ttdUniversalPixelTagfb79dc7af6cc4733a9c4a87c68c6f55e");
	                }
	            })(this);
	        </script>
	    </div>


	 
			
			
	</body>
</html>

