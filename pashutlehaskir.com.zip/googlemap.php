<script src="js/jquery.min.js"></script>
<script type="text/javascript">


<div style="width: 330px;margin-left: 15px;">
<iframe width="330" height="220" src="http://regiohelden.de/google-maps/map_en.php?width=330&amp;height=220&amp;hl=en&amp;q=<?php echo $map_address; ?>+(<?php echo $company_name; ?>)&amp;ie=UTF8&amp;t=&amp;z=9&amp;iwloc=A&amp;output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"><a href="http://www.regiohelden.de/google-maps/">Google Maps Script</a> von <a href="http://www.regiohelden.de/">RegioHelden</a></iframe><br /><span style="font-size: 7px;"><a href="http://www.regiohelden.de/google-maps/" style="font-size: 7px;">Google Maps Script</a> by <a href="http://www.regiohelden.de/" style="font-size: 7px;">RegioHelden</a></span></div></div>

  </script>