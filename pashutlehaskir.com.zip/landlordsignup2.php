<?php
include_once('functions/function.php');
// print_r($_POST);
$data['member_type']='landlord';
$data['first_name']=$_POST['first_name'];
$data['last_name']=$_POST['last_name'];
$data['email']=$_POST['ll_email'];
$data['mem_phone_a']=$_POST['ll_phone_a'];
$data['mem_phone_b']=$_POST['ll_phone_b'];
$data['mem_phone_c']=$_POST['ll_phone_c'];
$data['mem_street_number']=$_POST['ll_street_number'];
$data['mem_street_address']=$_POST['ll_street_address'];
$data['mem_city']=$_POST['ll_city'];
$data['mem_state']=$_POST['ll_state'];
$data['mem_zipcode']=$_POST['ll_zipcode'];
$data['ll_type']=$_POST['landlord_type_id'];
$data['username']=$_POST['username'];
$data['password']=$_POST['password'];
$data['accept_terms']=$_POST['llterms'];
$data['accept_foreclosure']=$_POST['nofc'];
$data['accept_credit_check']=$_POST['credit_check'];
$data['accept_pm_brokerage']=$_POST['pm_brokerage'];

$WHERE['username']=$_POST['username'];
$exst=isExist('members',$WHERE);
// print_r($exst);die;
if($exst== true)
{
	echo "<script>setTimeout(function(){window.history.back();},3000);</script><h4 style='z-index:99; background-color:#FF3366;width:50%; top:45%; left:25%; position: absolute; padding:15px 15px; color: #fff; text-align:center; font-size:18px;'>Username already exist, choose another Username</h4>";
}
else
{
	if(insert('members',$data,'member_id','member_id'))
	{
		echo "<script>setTimeout(function(){window.location.href='index.php'},2000);</script><h4 style='z-index:99; background-color:#5cb85c;width:50%; top:45%; left:25%; position: absolute; padding:15px 15px; color: #fff; text-align:center; font-size:18px;'>Registeration Successfull !</h4>";
	}
	else
	{
		echo "<script>setTimeout(function(){window.history.back();},2000);</script><h4 style='z-index:99; background-color:#FF3366;width:50%; top:45%; left:25%; position: absolute; padding:15px 15px; color: #fff; text-align:center; font-size:18px;'>Failed To Register Membership ! Please Try Again Later</h4>";
	}	
}

	

?>