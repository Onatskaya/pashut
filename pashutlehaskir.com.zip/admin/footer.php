<div class="container-fluid footer">					
	<div class="container-fluid footer-links">
		<div class="row">
			<div class="col-md-2">
				<img src="../images/logo_footer.png" width="175">
			</div>
			<div class="col-md-6"></div>
			<div class="col-md-4" align="right">
				<!-- <ul class="list-inline">
					<li ><a href="../termsofuse.php">Terms of Use</a></li>
					<li ><a href="../find.php">Contact Us</a></li>
					<li ><a href="../legal.php">Legal Info</a></li>
					<li ><a href="../privacy.php">Privacy Policy</a></li>
					<li ><a href="../feedback.php">Feedback</a></li>
					<li ><a href="../faq.php">Faq's</a></li>
					<li ><a href="../jobs.php">Jobs</a></li>
					<li ><a href="../sitemap.php">Sitemap</a></li>
					<li class="copyright">
					 Copyright &copy; 2016 pashutlehaskir.com All rights reserved.
					</li>
				</ul> -->
				<p>Copyright &copy; 2016 pashutlehaskir.com All rights reserved.</p>
				
				
				
			</div>	
		</div>
	</div>
		
	</div>
	


<div id="fb-root"></div>