<div class="container-fluid footer">
	<!-- <div class="container highlight-section">
		<div class="col-md-8">
			<h2>AS SEEN IN </h2>
			<img src="images/2016/as-seen-banner.jpg" />
		</div>
		<div class="col-md-4">
			<a href="#"><img src="images/2016/download-app-banner.jpg" /></a>
		</div>
	</div> -->
	<!-- <div class="container-fluid disclaimer">
		<div class="col-md-12 col-xs-12  text-center">
			Pashutle haskir is bonded and the only non restricted fully licensed rental service under the California Bureau of Real Estate.
		</div>
	</div> -->
					
	<div class="container-fluid footer-links">
		<div class="row">
			<div class="col-md-10 col-xs-12">
				<ul class="list-inline">
					<li ><a href="termsofuse_h.php">תנאי שימוש</a></li>
					<li ><a href="contactus_h.php">צור קשר</a></li>
					<!--<li ><a href="legal.php">Legal Info</a></li>-->
					<li ><a href="privacy_h.php">מדיניות פרטיות</a></li>
					
					<li class="dropdown">
					  <a href="aboutus_h.php" class="dropdown-toggle">אודותינו</a>
					</li>

					<!-- <li ><a href="feedback.php">Feedback</a></li> -->
					<li ><a href="faq_h.php">שאלות נפוצות</a></li>
					<!-- <li ><a href="jobs.php">Jobs</a></li>
					<!-- <li ><a href="sitemap.php">Sitemap</a></li> -->
					<li class="copyright">
					
					 כל הזכויות שמורות © 2016 פשוט להשכיר.
				
					</li>
				
				</ul>
				
			</div>
			<div class="col-md-2 col-xs-12">
				<img src="images/logo_footer.png" width="175">
			</div>
		</div>
	</div>
	
</div>
<div id="fb-root"></div>