<?php

include_once('functions/function.php');
if($_SESSION['language']=='English')
{
	echo "<script>location.href='privacy.php'</script>";
}
?>
<!DOCTYPE HTML> 
<html lang="en">
  <head>

  	
 
		
				<title>pashutlehaskir.com</title>
				<link rel="shortcut icon" href="#" />
				<meta charset="utf-8">
				<meta http-equiv="X-UA-Compatible" content="IE=edge">
				<html dir="rtl" lang="he">
				<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, width=device-width">
				<meta http-equiv="expires" content="0" />
				<meta http-equiv="Pragma" content="no-cache" />
				<meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8" />

				
       			<meta name="apple-itunes-app" content="app-id=509021914">
   				

					<script type="text/javascript">
setTimeout(function(){var a=document.createElement("script");
var b=document.getElementsByTagName("script")[0];
a.src=document.location.protocol+"//script.crazyegg.com/pages/scripts/0044/7420.js?"+Math.floor(new Date().getTime()/3600000);
a.async=true;a.type="text/javascript";b.parentNode.insertBefore(a,b)}, 1);
</script>

<script>
var _prum = [['id', '56a93ecdabe53ddd5a18ddad'],
             ['mark', 'firstbyte', (new Date()).getTime()]];
(function() {
    var s = document.getElementsByTagName('script')[0]
      , p = document.createElement('script');
    p.async = 'async';
    p.src = '//rum-static.pingdom.net/prum.min.js';
    s.parentNode.insertBefore(p, s);
})();
</script> 

			<script type="text/javascript">
			function movetoNext(current, nextFieldID) {
			if (current.value.length >= current.maxLength) {
			document.getElementById(nextFieldID).focus();
			}
			}
			</script>
			 <!-- Google Fonts embed code -->
			<script type="text/javascript">
				(function() {
					var link_element = document.createElement("link"),
						s = document.getElementsByTagName("script")[0];
					if (window.location.protocol !== "http:" && window.location.protocol !== "https:") {
						link_element.href = "http:";
					}
					link_element.href += "//fonts.googleapis.com/css?family=Lato:100italic,100,300italic,300,400italic,400,700italic,700,900italic,900";
					link_element.rel = "stylesheet";
					link_element.type = "text/css";
					s.parentNode.insertBefore(link_element, s);
				})();
			</script>


							
				<!-- Latest compiled and minified CSS -->
				<link href="css/201603/ui-lightness/jquery-ui-1.10.4.css" rel="stylesheet">
				<link rel="stylesheet" href="css/bootstrap.min.css">
				<!-- Custom styles for this template -->
				<link href="css/201603/global.css" rel="stylesheet">
				<link href="css/201603/section.css" rel="stylesheet">
				<link href="css/201603/carousel.css" rel="stylesheet">
			
					<meta name="keywords" content="pashutlehaskir.com | Rent SoCal Houses, Apartments & More, Los Angeles rentals, Santa Monica House, South Bay Rentals, Los Angeles Apartments, Orange County Rentals, San Diego Apartments, Hermosa Beach Apartments, Hollywood For Rent, Burbank Apartments, Glendale Homes, Studio City Rentals, Apartments for Rent, Houses for Rent, Condos for Rent, Apartments in Los Angeles, Apartments in LA, USC, University of Southern California, Cal State, California State University, UCLA, University of California, University of California Los Angeles, Loyola Marymount University, Pepperdine, Pepperdine University, USC Student Housing, USC Housing, USC Apartments, Cal State Housing, Cal State Student Housing, Cal State Apartments, UCLA Housing, UCLA Student Housing, UCLA Apartments, LMU Housing, LMU Student Housing, LMU Apartments, Pepperdine Housing, Pepperdine Student Housing, Pepperdine Apartments" />
				
					<meta name="description" content="pashutlehaskir.com is the #1 home finding service in the Los Angeles area. Search SoCal apartment rentals, houses, condos & roommates!" />
				
					<meta name="robots" content="index,follow" />
					<meta name="GOOGLEBOT" content="index,follow" />
				
			
			
			<meta name="google-translate-customization" content="954d153704cc37f5-fac58c9bb4d3c842-g115d03cfb1ac5d23-17"></meta>
			
			
        
	</head>

	
	<body  class="guest" >
	
	


	
		
		<div id="slidedown-content" data-status="hide" class="none">
			<div id="login-content" class="fb">
				<form action="login.php" name="loginForm" method="post">
					<span>
						<label>שם משתמש</label> 
						<input type="text" name="username" class="text" size="10" maxlength="100" />
					</span>
					<span>
						<label>סיסמה</label>
						<input type="password" autocomplete="off" class="text" name="password" size="10" maxlength="45" />
					</span>	

					
					<input type="image" name="login" class="submit" src="images/new/btn-login.png" align="absmiddle" />
					
					

				</form>
				<div class="separator">
				-------------- או --------------
				</div>
				<div class="fb-login-section">
				<a href="#" class="fb-login"><img src="images/fblogin.png"></a>
				</div>
			</div>		
		</div>
	
		<?php
		include('header_h.php');
		?>
	
	
    <!-- Carousel
    ================================================== -->
	<div class="container privacy">

<div class="oneColumnLayout static-page">
	
	<div class="col-md-12">
	 
<h1>מדיניות פרטיות</h1>

"פשוט להשכיר" מחויבת לשמירה על פרטיותך באינטרנט. אנא קרא את המדיניות הבאה כדי להבין כיצד אנו אוספים, משתמשים ומגינים על המידע שלך. מדיניות זו עשויה להשתנות, ולכן מומלץ לחזור ועיין בה מעת לעת. מדיניות זו תאפשר לך לדעת:

<ul style="margin-left:20px;">
<li>איזה מידע אישי נאסף ממך</li>
<li>
מהם "עוגיות" וכיצד משתמשים בהם
</li>
<li>
איך נעשה שימוש במידע שלך
</li>
<li>
מי אוסף את המידע שלך
</li>
<li>
עם מי המידע שלך עשוי להיות משותף
</li>
<li>
מה הן האפשרויות הזמינות לך בנוגע לאיסוף, שימוש והפצת המידע שלך
</li>
<li>
כיצד תוכל לגשת ולעדכן את המידע שלך
</li>
<li>
סוגי אמצעי האבטחה המופעלים כדי להגן מפני איבוד, שימוש לרעה או שינוי המידע שלך
</li>
<li>
מה עוד עליך לדעת בנוגע לפרטיות שלך באנטרנט 
</li>
</ul>

<h2>
איזה מידע אישי נאסף ממך
</h2>
"פשוט להשכיר" אוספת מידע במספר דרכים בכמה חלקים שונים באתר.
<br/>
במהלך תהליך הרישום לאתר, תתבקש להזין מספר פרטים אישיים. אנחנו מבקשים את שמך, כתובת דוא"ל, רחוב, עיר, מדינה/מחוז, מיקוד, מדינה, ומספר טלפון. אמנם, רק שדות המסומנים בכוכבית (*) בטופס ההרשמה הינם חובה. מידע זה משמש אך ורק כדי לסייע לך לנווט במערכת על ידי מילוי אוטומטי של טפסים מסוימים (כגון בטופס פרסום מודעה), כדי שלא תידרש להזין את המידע שלך בכל פעם מחדש. לאחר הרשמתך, הנך מזוהה על ידי "פשוט להשכיר". שם המשתמש והסיסמה שנוצרו במהלך הרישום יספקו לך גישה לכל שירותי ומשאבי "פשוט להשכיר".
<br/>
בנוסף למידע שנאסף במהלך הרישום, אנו עשויים לבקש ממך מידע אישי נוסף בזמנים אחרים, לרבות בשעת פרסום נכסים זמינים להשכרה, או בכל שימוש אחר בשירות של "פשוט להשכיר". אם תיצור איתנו קשר, אנו עשויים לשמור תיעוד של ההתכתבות בינינו. כל עמוד באתר "פשוט להשכיר" מכיל קישור למדיניות פרטיות זאת.
<br/>
<h2>
מהם "עוגיות" וכיצד משתמשים בהם
</h2>
כחלק ממתן שירות מותאם אישית למשתמשי האתר, "פשוט להשכיר" עשויה להשתמש בעוגיות כדי לאחסן ולפעמים לעקוב אחר מידע אודותיך. קובץ Cookie, המכיל כמות קטנה של נתונים, נשלח לדפדפן שלך משרת האינטרנט ומאוחסן על הכונן הקשיח של המחשב שלך. ישנם מספר מאפיינים של האתר של "פשוט להשכיר" הדורשים ממך לאשר שימוש בעוגיות כדי שיפעלו כראוי. (עיין בפרק "מה הן האפשרויות הזמינות לך בנוגע לאיסוף, שימוש והפצת המידע שלך" לקבלת מידע נוסף על עוגיות.)
<br/>
באופן כללי, אנו משתמשים בעוגיות למטרות הבאות:
<br/>

לזהות ולתייג כל נכס פנוי "חדש" מאז ביקורך האחרון באתר.
<br/>
באופן אופציונלי, לשמור את הסיסמה שלך לחשבון באופן קבוע במחשבך, כדי שלא תידרש להזין אותה מחדש בכל ביקור שלך באתר.
<br/>
לאפשר לך להשוות בין נכסים פנויים שברצונך לסמן עבור צפייה עתידית.
<br/>
רשתות פרסום המפרסמות מודעות באתר "פשוט להשכיר" עשויות להשתמש בעוגיות משלהן.
<br/>
"פשוט להשכיר" עשויה כמו כן לאסוף כתובות IP לניהול המערכת, מניעת רמאויות, ולדווח על מיד סטטיסטי מצטבר לסוכני הפרסום שלנו.
<br/>
<h2>
איך נעשה שימוש במידע שלך
</h2>
מטרתה העיקרית של "פשוט להשכיר" באיסוף מידע אישי הינה לספק לך, המשתמש, חוויה מותאמת אישית, ולסייע לך לנווט באתר של "פשוט להשכיר".

<br/>

<h2>
מי אוסף את המידע שלך

</h2>

כאשר הנך מתבקש להזין פרטים אישיים באתר "פשוט להשכיר", הנך משתף מידע עם "פשוט להשכיר" בלבד, אלא אם כן נאמר אחרת במפורש. עם זאת, ישנן פעילויות שמעצם טבען יחשפו את המידע האישי שלך למשתמשים נוספים של "פשוט להשכיר". לדוגמה, הפרטים האישיים שתזין בטופס פרסום של נכס פנוי להשכרה יוצגו במודעה של הנכס שלך, אלא אם צוין אחרת. כמו כן, אם תבקש מאחד מהשותפים שלנו המפרסמים באתר ליצור איתך קשר, חלק מפרטי יצירת הקשר עמך ישותף עימם.

<br/>

<h2>עם מי המידע שלך עשוי להיות משותף
</h2>

ככלל, "פשוט להשכיר" לא תחשוף אף מידע המזהה אותך באופן אישי, למעט כאשר תתקבל הסכמתך לכך, ולמעט נסיבות מיוחדות, למשל כשאנו סבורים בתום לב שהחוק דורש זאת, או בנסיבות המתוארות להלן. נא עיין בתנאי השימוש לקבלת מידע מפורט יותר על המקרים שבהם המידע שלך עשוי להיות משותף עם אחרים.

<br/>
"פשוט להשכיר" עשויה לחשוף מידע אודות חשבונות במקרים מיוחדים, כאשר יש לנו סיבה להאמין כי חשיפת מידע זה נחוץ כדי לזהות, ליצור קשר או לפתוח בהליך משפטי כנגד אדם אשר עלול להפר את תנאי השימוש של "פשוט להשכיר", או כאשר אדם זה עשוי לפגוע (בכוונה או שלא בכוונה) בזכויות הקניין של "פשוט להשכיר", משתמשים אחרים באתר, או כל אחד אחר שעשוי להיפגע מפעילויות כאלה. "פשוט להשכיר" עשויה לחשוף או לגשת למידע של חשבון מסוים, כאשר אנו סבורים בתום לב שהחוק דורש זאת, וכן למטרות מנהליות ואחרות שאנו מעריכים שנחוצות לצורך מתן, תחזוק, ושיפור המוצרים והשירותים שלנו.

<br/>

<h2>
מה הן האפשרויות הזמינות לך בנוגע לאיסוף, שימוש והפצת המידע שלך

</h2>
אם תבחר שלא להירשם או שלא למסור מידע אישי, הנך עדיין יכול להשתמש ברוב השירותים הניתנים על ידי "פשוט להשכיר", אבל לא תוכל להשתמש באפשרויות או לגשת לשירותים הדורשים רישום.

<br/>
כמו כן, באפשרותך לבחור כיצד משתמשים בעוגיות. על ידי שינוי הגדרות הדפדפן שלך, תוכל לבחור האם לאשר הורדת עוגיות, לקבל הודעה כאשר מתקבלת עוגיה, או לדחות את כל העוגיות. אם תבחר לדחות את כל העוגיות, לא תוכל להשתמש בשירותים ותכונות של "פשוט להשכיר" הדורשים רישום. שירותים אלה כוללים זיהוי של נכסים פנויים חדשים שפורסמו מאז הביקור האחרון שלך, ומילוי אוטומטי של טופס ההתחברות לאתר, ותכונת המועדפים. באפשרותך עדיין להשתמש ברוב התכונות של "פשוט להשכיר", גם אם אינך מאשר הורדת עוגיות.
<br/>

<h2>
כיצד תוכל לגשת ולעדכן את המידע שלך

</h2>
אנו נספק לך את האמצעים כדי להבטיח כי המידע האישי שלך יהיה נכון ומעודכן. תוכל לערוך את פרופיל המשתמש שלך בכל עת על ידי לחיצה על הקישור "הפרופיל שלי" המוצג על ידי המערכת לאחר התחברותך לאתר. מרגע התחברותך לאתר, בכל מהלך ניווטך באתר, המידע שלך יישמר עד ללחיצתך על קישור ה"ניתוק", שיוצג בעמוד "החשבון שלי".

<br/>
אם הנך משתמש רשום ואיבדת או שכחת את הסיסמה שלך, תוכל לקבלה בדוא"ל באמצעות לחיצה על קישור "שכחתי את הסיסמה". לחץ על הקישור הנ"ל כדי לבקש מאיתנו לשלוח לך את הסיסמה בדוא"ל. איננו יכולים לספק לך את הסיסמה שלך בכל דרך אחרת.

<br/>
סוגי אמצעי האבטחה המופעלים כדי להגן מפני איבוד, שימוש לרעה או שינוי המידע שלך

<br/>
מלבד למנהל אתר "פשוט להשכיר" וצוות האתר המורשה לכך, הנך האדם היחיד עם גישה למידע האישי שלך. חשבון המשתמש שלך מוגן בסיסמה כדי למנוע גישה לא מורשית.

<br/>
אנו ממליצים לא לחשוף את הסיסמה שלך לפני לאף אחד. "פשוט להשכיר" לעולם לא תבקש ממך את הסיסמה שלך באמצעות שיחת טלפון או הודעת דוא"ל שאינם יזומים על ידך. כאמצעי אבטחה נוסף, ייתכן כי תרצה להתנתק מחשבונך לאחר סיום שימושך באתר "פשוט להשכיר". פעולה זאת תוודא שאחרים לא יוכלו לגשת למידע האישי שלך במקרים שבהם המחשב האישי שלך משותף עם משתמשים אחרים, או במידה והנך משתמש במחשב במקום ציבורי כגון ספריה, או בית קפה עם שירות אנטרנט.

<br/>
למרבה הצער, לא ניתן להבטיח העברת מידע באופן בטוח דרך האינטרנט ב-100%. כתוצאה מכך, בעוד שאנו מתאמצים להגן על המידע האישי שלך, "פשוט להשכיר" אינה יכולה להבטיח או לערוב לביטחון כל מידע שתעביר אלינו או מהשירותים המקוונים שלנו, והנך עושה זאת על אחריותך בלבד. עם קבלת המידע שלך, אנו עושים את מירב המאמצים על מנת להבטיח את ביטחון המידע על המערכות שלנו.

<br/>

<H2>
מה עוד עליך לדעת בנוגע לפרטיות שלך באנטרנט

</h2>
נא זכור שבכל פעם שהנך חושף את פרטיך האישיים באנטרנט, למשל בפרסום מידע על הנכס שלך באתר או באמצעות דוא"ל, משתמשים אחרים יכולים לאסוף מידע זה ולהשתמש בו. בקיצור, אם הנך מפרסם באינטרנט מידע אישי הנגיש לציבור, אתה עשוי לקבל הודעות לא רצויות מצדדים אחרים.

<br/>
בסופו של דבר, אתה האחראי הבלעדי על שמירת הסודיות של הסיסמאות ו/או כל מידע על חשבונך. עליך לנהוג במשנה זהירות ובאחריות במהלך פעילותך באנטרנט.

<br/>
נא שים לב כי כאשר הנך מתכתב עם בעל נכס כלשהו, כתובת הדוא"ל של בעל הנכס והלקוח ייחשפו אך ורק זה לזה. הכתובות לא ייחשפו בפני כל מקור אחר. ברישומך לאתר הנך מסכים לתנאי זה.


	
		
	</div>
</div>

</div> <!-- End main container div -->
	
	
	<!-- FOOTER -->
		<?php
			include('footer_h.php');
		?>
		
		
		
	
	
	<!-- Bootstrap core JavaScript
	================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery.min.js"></script>
	

	
	<script src="js/new/jquery-ui-1.10.4/jquery-ui-1.10.4.js"></script>
	<script src="js/new/jquery.cycle.all.js"></script>
	
	<!-- Latest compiled and minified JavaScript -->
	<script src="js/bootstrap.min.js"></script>
	
	
			
	<script src="js/fb_login.js"></script>	
	<script src="js/navigation/menu.js" type="text/javascript" language="javascript"></script>	
	<script src="js/default.js" type="text/javascript" language="javascript"></script>	

	<script src="js/ddaaccordion.js" type="text/javascript" language="javascript"></script>


	
	<!-- Default JavaScript -->
	<script src="js/new/default.js"></script>
	
	
	<!-- Pretty photo --->
	<link rel="stylesheet" href="../js/new/prettyphoto/css/prettyPhoto.css" type="text/css" media="screen" charset="utf-8" />
	<script src="../js/new/prettyphoto/js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>
	
	
	<script src="../js/tooltips/wz_tooltip.js" type="text/javascript" language="javascript"></script>
			
			
				


		
	<div id="ttdUniversalPixelTagfb79dc7af6cc4733a9c4a87c68c6f55e" style="display:none">
	        <script src="https://js.adsrvr.org/up_loader.1.1.0.js" type="text/javascript"></script>
	        <script type="text/javascript">
	            (function(global) {
	                if (typeof TTDUniversalPixelApi === 'function') {
	                    var universalPixelApi = new TTDUniversalPixelApi();
	                    universalPixelApi.init("nalbr2d", ["k56d7yb"], "https://insight.adsrvr.org/track/up", "ttdUniversalPixelTagfb79dc7af6cc4733a9c4a87c68c6f55e");
	                }
	            })(this);
	        </script>
	    </div>


	 
			
			
	</body>
</html>

