<div class="container-fluid footer">					
	<div class="container-fluid footer-links">
		<div class="row">
			<div class="col-md-10 col-xs-12">
				<ul class="list-inline">
					<li ><a target="_blank" href="../termsofuse.php">תנאי שימוש</a></li>
					<li ><a target="_blank" href="../contactus.php">צור קשר</a></li>
					<li ><a target="_blank" href="../legal.php">משפטי</a></li>
					<li ><a target="_blank" href="../privacy.php">מדיניות פרטיות</a></li>
					<!-- <li ><a href="../feedback.php">Feedback</a></li> -->
					<li ><a target="_blank" href="../faq.php">שאלות נפוצות</a></li>
					<!-- <li ><a href="../sitemap.php">Sitemap</a></li> -->
					<li class="copyright">
					
					 כל הזכויות שמורות © 2016 פשוט להשכיר.
				
					</li>
				
				</ul>
				
			</div>	
			<div class="col-md-2 col-xs-12">
				<img src="../images/logo_footer.png" width="175">
			</div>
			
		</div>
	</div>
		
	</div>
	


<div id="fb-root"></div>