<?php
if($data['refrigerator']=='yes')
{ ?>
	<li><?php echo 'מקרר';?></li>
<?php }
?>

<?php
if($data['air_conditioner']=='yes')
{ ?>
	<li><?php echo 'מזגן' ;?></li>
<?php }
?>

<?php
if($data['yard']=='yes')
{ ?>
	<li><?php echo 'חצר' ;?></li>
<?php }
?>

<?php
if($data['stove']=='yes')
{ ?>
	<li><?php echo 'תנור' ;?></li>
<?php }
?>

<?php
if($data['wallheater']=='yes')
{ ?>
	<li><?php echo 'מחמם קיר' ;?></li>
<?php }
?>

     
<?php
if($data['elevator']=='yes')
{ ?>
	<li><?php echo 'מעלית' ;?></li>
<?php }
?>

<?php
if($data['dishwasher']=='yes')
{ ?>
	<li><?php echo 'מדיח כלים' ;?></li>
<?php }
?>

<?php
if($data['laundry']=='yes')
{ ?>
	<li><?php echo 'כביסה במקום' ;?></li>
<?php }
?>

<?php
if($data['pool']=='yes')
{ ?>
	<li><?php echo 'בריכה' ;?></li>
<?php }
?>

<?php
if($data['microwave']=='yes')
{ ?>
	<li><?php echo 'מיקרוגל' ;?></li>
<?php }
?>

<?php
if($data['wd']=='yes')
{ ?>
	<li><?php echo 'מכונות כביסה וייבוש בבניין' ;?></li>
<?php }
?>

<?php
if($data['spa']=='yes')
{ ?>
	<li><?php echo "ספא/ג'קוזי" ;?></li>
<?php }
?>

<?php
if($data['central_air']=='yes')
{ ?>
	<li><?php echo 'מיזוג מרכזי' ;?></li>
<?php }
?>

<?php
if($data['wd_hookups']=='yes')
{ ?>
	<li><?php echo 'חיבורים למכונות כביסה וייבוש' ;?></li>
<?php }
?>

<?php
if($data['accessiblee']=='yes')
{ ?>
	<li><?php echo 'נגיש לכסא גלגלים' ;?></li>
<?php }
?>

<?php
if($data['central_heat']=='yes')
{ ?>
	<li><?php echo 'חימום מרכזי' ;?></li>
<?php }
?>

<?php
if($data['balcony']=='yes')
{ ?>
	<li><?php echo 'מרפסת' ;?></li>
<?php }
?>

<?php
if($data['controlled_access']=='yes')
{ ?>
	<li><?php echo 'בניין עם גישה מבוקרת' ;?></li>
<?php }
?>

<?php
if($data['fireplace']=='yes')
{ ?>
	<li><?php echo 'אח' ;?></li>
<?php }
?>

<?php
if($data['patio']=='yes')
{ ?>
	<li><?php echo 'פטיו' ;?></li>
<?php }
?>

<?php
if($data['quiet_nhood']=='yes')
{ ?>
	<li><?php echo 'שכונה שקטה' ;?></li>
<?php }
?>




