<?php
if($data['refrigerator']=='yes')
{ ?>
	<li><?php echo 'Refrigerator';?></li>
<?php }
?>

<?php
if($data['air_conditioner']=='yes')
{ ?>
	<li><?php echo 'Air Conditioner' ;?></li>
<?php }
?>

<?php
if($data['yard']=='yes')
{ ?>
	<li><?php echo 'Yard' ;?></li>
<?php }
?>

<?php
if($data['stove']=='yes')
{ ?>
	<li><?php echo 'Stove' ;?></li>
<?php }
?>

<?php
if($data['wallheater']=='yes')
{ ?>
	<li><?php echo 'Wall Heater' ;?></li>
<?php }
?>

     
<?php
if($data['elevator']=='yes')
{ ?>
	<li><?php echo 'Elevator' ;?></li>
<?php }
?>

<?php
if($data['dishwasher']=='yes')
{ ?>
	<li><?php echo 'Dishwasher' ;?></li>
<?php }
?>

<?php
if($data['laundry']=='yes')
{ ?>
	<li><?php echo 'Laundry on premises' ;?></li>
<?php }
?>

<?php
if($data['pool']=='yes')
{ ?>
	<li><?php echo 'Pool' ;?></li>
<?php }
?>

<?php
if($data['microwave']=='yes')
{ ?>
	<li><?php echo 'Microwave' ;?></li>
<?php }
?>

<?php
if($data['wd']=='yes')
{ ?>
	<li><?php echo 'Washer and Dryer in Unit' ;?></li>
<?php }
?>

<?php
if($data['spa']=='yes')
{ ?>
	<li><?php echo 'Spa/Jacuzzi' ;?></li>
<?php }
?>

<?php
if($data['central_air']=='yes')
{ ?>
	<li><?php echo 'Central Air' ;?></li>
<?php }
?>

<?php
if($data['wd_hookups']=='yes')
{ ?>
	<li><?php echo 'Washer and Dryer Hookups' ;?></li>
<?php }
?>

<?php
if($data['accessiblee']=='yes')
{ ?>
	<li><?php echo 'Wheelchair Accessible' ;?></li>
<?php }
?>

<?php
if($data['central_heat']=='yes')
{ ?>
	<li><?php echo 'Central Heat' ;?></li>
<?php }
?>

<?php
if($data['balcony']=='yes')
{ ?>
	<li><?php echo 'Balcony' ;?></li>
<?php }
?>

<?php
if($data['controlled_access']=='yes')
{ ?>
	<li><?php echo 'Controlled Access Building' ;?></li>
<?php }
?>

<?php
if($data['fireplace']=='yes')
{ ?>
	<li><?php echo 'Fireplace' ;?></li>
<?php }
?>

<?php
if($data['patio']=='yes')
{ ?>
	<li><?php echo 'Patio' ;?></li>
<?php }
?>

<?php
if($data['quiet_nhood']=='yes')
{ ?>
	<li><?php echo 'Quiet Neighborhood' ;?></li>
<?php }
?>




