<?php
include_once('functions/function.php');
$que_city="SELECT * FROM city ";
$obj_city=mysqli_query($conn,$que_city);
while($data_city3=mysqli_fetch_assoc($obj_city))
{
	$data_city2[]=$data_city3;
}


?>
	
      
    <!DOCTYPE HTML> 
<html lang="en">
  <head>

  	
 
		
				<title>pashutlehaskir.com</title>
				<link rel="shortcut icon" href="#" />
				<meta charset="utf-8">
				<meta http-equiv="X-UA-Compatible" content="IE=edge">
				
				<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, width=device-width">
				<meta http-equiv="expires" content="0" />
				<meta http-equiv="Pragma" content="no-cache" />
				<meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8" />

				
       			<meta name="apple-itunes-app" content="app-id=509021914">
   				
       				<script type="text/javascript">
setTimeout(function(){var a=document.createElement("script");
var b=document.getElementsByTagName("script")[0];
a.src=document.location.protocol+"//script.crazyegg.com/pages/scripts/0044/7420.js?"+Math.floor(new Date().getTime()/3600000);
a.async=true;a.type="text/javascript";b.parentNode.insertBefore(a,b)}, 1);
</script>

<script>
var _prum = [['id', '56a93ecdabe53ddd5a18ddad'],
             ['mark', 'firstbyte', (new Date()).getTime()]];
(function() {
    var s = document.getElementsByTagName('script')[0]
      , p = document.createElement('script');
    p.async = 'async';
    p.src = '//rum-static.pingdom.net/prum.min.js';
    s.parentNode.insertBefore(p, s);
})();
</script> 

			<script type="text/javascript">
			function movetoNext(current, nextFieldID) {
			if (current.value.length >= current.maxLength) {
			document.getElementById(nextFieldID).focus();
			}
			}
			</script>
			 <!-- Google Fonts embed code -->
			<script type="text/javascript">
				(function() {
					var link_element = document.createElement("link"),
						s = document.getElementsByTagName("script")[0];
					if (window.location.protocol !== "http:" && window.location.protocol !== "https:") {
						link_element.href = "http:";
					}
					link_element.href += "//fonts.googleapis.com/css?family=Lato:100italic,100,300italic,300,400italic,400,700italic,700,900italic,900";
					link_element.rel = "stylesheet";
					link_element.type = "text/css";
					s.parentNode.insertBefore(link_element, s);
				})();
			</script>


				
			
				<!-- Latest compiled and minified CSS -->
				<link href="css/201603/ui-lightness/jquery-ui-1.10.4.css" rel="stylesheet">
				<link rel="stylesheet" href="css/bootstrap.min.css">
				<!-- Custom styles for this template -->
				<link href="css/201603/global.css" rel="stylesheet">
				<link href="css/201603/section.css" rel="stylesheet">
				<link href="css/201603/carousel.css" rel="stylesheet">
			
					<meta name="keywords" content="pashutlehaskir.com | Rent SoCal Houses, Apartments & More, Los Angeles rentals, Santa Monica House, South Bay Rentals, Los Angeles Apartments, Orange County Rentals, San Diego Apartments, Hermosa Beach Apartments, Hollywood For Rent, Burbank Apartments, Glendale Homes, Studio City Rentals, Apartments for Rent, Houses for Rent, Condos for Rent, Apartments in Los Angeles, Apartments in LA, USC, University of Southern California, Cal State, California State University, UCLA, University of California, University of California Los Angeles, Loyola Marymount University, Pepperdine, Pepperdine University, USC Student Housing, USC Housing, USC Apartments, Cal State Housing, Cal State Student Housing, Cal State Apartments, UCLA Housing, UCLA Student Housing, UCLA Apartments, LMU Housing, LMU Student Housing, LMU Apartments, Pepperdine Housing, Pepperdine Student Housing, Pepperdine Apartments" />
				
					<meta name="description" content="pashutlehaskir.com is the #1 home finding service in the Los Angeles area. Search SoCal apartment rentals, houses, condos & roommates!" />
				
					<meta name="robots" content="index,follow" />
					<meta name="GOOGLEBOT" content="index,follow" />
				
			
			
			<meta name="google-translate-customization" content="954d153704cc37f5-fac58c9bb4d3c842-g115d03cfb1ac5d23-17"></meta>
			
			
        
	</head>

	
	<body  class="guest" >
	
	


	
		
		<div id="slidedown-content" data-status="hide" class="none">
			<div id="login-content" class="fb">
				<form action="login.php" name="loginForm" method="post">
					<span>
						<label>Username</label> 
						<input type="text" name="username" class="text" size="10" maxlength="100" />
					</span>
					<span>
						<label>Password</label>
						<input type="password" autocomplete="off" class="text" name="password" size="10" maxlength="45" />
					</span>	

					
					<input type="image" name="login" class="submit" src="images/new/btn-login.png" align="absmiddle" />
					
					

				</form>
				<div class="separator">
				-------------- OR --------------
				</div>
				<div class="fb-login-section">
				<a href="#" class="fb-login"><img src="images/fblogin.png"></a>
				</div>
			</div>		
		</div>
	
		<?php
		include('header.php');
		?>
	<div class="container">

<div class="seo-page">
	<h1>Watts Apartments</h1>
	
	<div class="col-md-9">

		<div class="centerModule">
				
	
			
			
			<div class="pagination" style="margin:0; padding:0;">
				<ul>
					
							<li><a href="watts-apartments.html##" class="currentpage">1</a></li>
						
				</ul>
			</div>
			<div class="clearfix"><br><br></div>
			
			<form action="watts-apartments.html" method="post" name="goToForm">
				<input type="hidden" name="PAGENUM" value="1">
				
				
					<div id="idclass_1290161" class="rowOff" onMouseOver="toggle('idclass_1290161');" onmouseout="toggle('idclass_1290161');">
						
				<div id="listing_1290161" class="ListingListModule ListingTheme_Guest row">
					<div class="col-md-5 image_wrapper">
						<div class="crop">
							
							<a href="https://www.pashutlehaskir.com/listingdetail/1290161/watts/apartment/">
							
								<img src="images/hotel4.jpg" alt="Watts Fourplex">
							
							
							</a>
						</div>
						
					</div>
					<div class="col-md-7 text_wrapper">
						

						<div class="header">
							
							<a href="https://www.pashutlehaskir.com/listingdetail/1290161/watts/apartment/" class="price">
								$1,200.00
							</a>
							<a href="https://www.pashutlehaskir.com/listingdetail/1290161/watts/apartment/" class="headline">
								Watts Fourplex - Apartment
							</a>
							
							<div class="location">Location: Watts, CA 90002</div>
							
								<span class="available">Available Now</span>
							
						</div>

						<div class="data_text">
							
							Unfurnished,
										Upper,
										Fourplex,
										No pets, 2 bedrooms, 1 Bath, One year minimum lease, Floor type not specified, 1-car Parking included,
							stove, **Shown ONLY By Open House** 

Spacious upper unit with new blinds, new stove and fresh paint. One (1) assigned parking space. Small, cozy complex (4 units total). 

Owner is currently participating in the LA City Section 8 program. 

This building is not a pet friendly building with the exception of certified guide, signal, or service dogs. No satellite dishes allowed, $1,200.00, 800 deposit, 
						
							<div class="icons">
								
		<a href="#"  onmouseover="Tip('This listing includes photos. Click to view photos.',WIDTH, -350, SHADOW, true, FADEIN, 500, FADEOUT, 1000, BGCOLOR, '#FF8', BORDERCOLOR, '#FC0', PADDING, 5, FONTWEIGHT, 'bold', FONTSIZE, '11px')" onmouseout="UnTip()"><img src="images/2016/icons/photos-listingicon.png" border="0" align="absmiddle" class=""/></a>
	
		<a href="#"  onmouseover="Tip('This listing has a Map. Click to view the Map.',WIDTH, -350, SHADOW, true, FADEIN, 500, FADEOUT, 1000, BGCOLOR, '#FF8', BORDERCOLOR, '#FC0', PADDING, 5, FONTWEIGHT, 'bold', FONTSIZE, '11px')" onmouseout="UnTip()"><img src="images/2016/icons/pin-listingicon.png" border="0" align="absmiddle" class=""/></a>
	
		<a href="javascript:void(0);"  onmouseover="Tip('Parking available.  See listing for parking details.',WIDTH, -350, SHADOW, true, FADEIN, 500, FADEOUT, 1000, BGCOLOR, '#FF8', BORDERCOLOR, '#FC0', PADDING, 5, FONTWEIGHT, 'bold', FONTSIZE, '11px')" onmouseout="UnTip()"><img src="images/2016/icons/parking-listingicon.png" border="0" align="absmiddle" class=""/></a>
		
								
							</div>
							
							
							

                           
							
							<span class="detailLink "><a href="#"><b>See Listing Details</b></a></span>
							
							
								<a class="payrentLink" href="#">Pay Rent Online</a>
												
								<a href="join.php" class="btn_submit" style="float:left;">
									Join Now
								</a>
							

						
						</div> 
					</div> 

				
		

	</div>
	<div class="clearboth"></div>

					</div>
							
			</form>
			
			<div class="pagination" style="margin:10px 0 0; padding:0;">
				<ul>
					
							<li><a href="watts-apartments.html##" class="currentpage">1</a></li>
						
				</ul>
			</div>
			<div class="clearfix"></div>		
		</div>
	</div>
	<div class="col-md-3"> 
		

<div class="commonModule QuickSearchModule">
	<form action="guestsearch.php" name="searchForm" method="get">
		<div class="line">
			<h3>Search Now for <strong>FREE!</strong></h3>
			<label>Search Area:</label>
			<select name="city">
				<?php
					foreach($data_city2 as $data_city)
					{ ?>
						<option><?php echo $data_city['city_name'];?></option>
				<?php }
				?>
			</select>
		</div>
		<div class="line">
			<label>Price Range:</label>
			<select name="priceLow" class="small">
				<option value="0">From:</option>
				<option value="">$0</option>
				
				<option value="500">$500</option>
				
				<option value="1000">$1000</option>
				
				<option value="1500">$1500</option>
				
				<option value="2000">$2000</option>
				
				<option value="2500">$2500</option>
				
				<option value="3000">$3000</option>
				
				<option value="3500">$3500</option>
				
				<option value="4000">$4000</option>
				
				<option value="4500">$4500</option>
				
				<option value="5000">$5000</option>
				
				<option value="5500">$5500</option>
				
				<option value="6000">$6000</option>
				
				<option value="6500">$6500</option>
				
				<option value="7000">$7000</option>
				
				<option value="7500">$7500</option>
				
				<option value="8000">$8000</option>
				
				<option value="8500">$8500</option>
				
				<option value="9000">$9000</option>
				
				<option value="9500">$9500</option>
				
				<option value="10000">$10000</option>
				
				<option value="10500">$10500</option>
				
				<option value="11000">$11000</option>
				
				<option value="11500">$11500</option>
				
				<option value="12000">$12000</option>
				
				<option value="12500">$12500</option>
				
				<option value="13000">$13000</option>
				
				<option value="13500">$13500</option>
				
				<option value="14000">$14000</option>
				
				<option value="14500">$14500</option>
				
				<option value="15000">$15000</option>
				
				<option value="15500">$15500</option>
				
				<option value="16000">$16000</option>
				
				<option value="16500">$16500</option>
				
				<option value="17000">$17000</option>
				
				<option value="17500">$17500</option>
				
				<option value="18000">$18000</option>
				
				<option value="18500">$18500</option>
				
				<option value="19000">$19000</option>
				
				<option value="19500">$19500</option>
				
				<option value="20000">$20000</option>
				
				<option value="20500">$20500</option>
				
				<option value="21000">$21000</option>
				
				<option value="21500">$21500</option>
				
				<option value="22000">$22000</option>
				
				<option value="22500">$22500</option>
				
				<option value="23000">$23000</option>
				
				<option value="23500">$23500</option>
				
				<option value="24000">$24000</option>
				
				<option value="24500">$24500</option>
				
				<option value="25000">$25000</option>
				
				<option value="25500">$25500</option>
				
				<option value="26000">$26000</option>
				
				<option value="26500">$26500</option>
				
				<option value="27000">$27000</option>
				
				<option value="27500">$27500</option>
				
				<option value="28000">$28000</option>
				
				<option value="28500">$28500</option>
				
				<option value="29000">$29000</option>
				
				<option value="29500">$29500</option>
				
				<option value="30000">$30000</option>
					
			</select>
			<span class="separator">-</span>
			<select name="priceHigh" class="small">
				<option value="0">To:</option>
					<option value="500">$500</option>
				
					<option value="1000">$1000</option>
				
					<option value="1500">$1500</option>
				
					<option value="2000">$2000</option>
				
					<option value="2500">$2500</option>
				
					<option value="3000">$3000</option>
				
					<option value="3500">$3500</option>
				
					<option value="4000">$4000</option>
				
					<option value="4500">$4500</option>
				
					<option value="5000">$5000</option>
				
					<option value="5500">$5500</option>
				
					<option value="6000">$6000</option>
				
					<option value="6500">$6500</option>
				
					<option value="7000">$7000</option>
				
					<option value="7500">$7500</option>
				
					<option value="8000">$8000</option>
				
					<option value="8500">$8500</option>
				
					<option value="9000">$9000</option>
				
					<option value="9500">$9500</option>
				
					<option value="10000">$10000</option>
				
					<option value="10500">$10500</option>
				
					<option value="11000">$11000</option>
				
					<option value="11500">$11500</option>
				
					<option value="12000">$12000</option>
				
					<option value="12500">$12500</option>
				
					<option value="13000">$13000</option>
				
					<option value="13500">$13500</option>
				
					<option value="14000">$14000</option>
				
					<option value="14500">$14500</option>
				
					<option value="15000">$15000</option>
				
					<option value="15500">$15500</option>
				
					<option value="16000">$16000</option>
				
					<option value="16500">$16500</option>
				
					<option value="17000">$17000</option>
				
					<option value="17500">$17500</option>
				
					<option value="18000">$18000</option>
				
					<option value="18500">$18500</option>
				
					<option value="19000">$19000</option>
				
					<option value="19500">$19500</option>
				
					<option value="20000">$20000</option>
				
					<option value="20500">$20500</option>
				
					<option value="21000">$21000</option>
				
					<option value="21500">$21500</option>
				
					<option value="22000">$22000</option>
				
					<option value="22500">$22500</option>
				
					<option value="23000">$23000</option>
				
					<option value="23500">$23500</option>
				
					<option value="24000">$24000</option>
				
					<option value="24500">$24500</option>
				
					<option value="25000">$25000</option>
				
					<option value="25500">$25500</option>
				
					<option value="26000">$26000</option>
				
					<option value="26500">$26500</option>
				
					<option value="27000">$27000</option>
				
					<option value="27500">$27500</option>
				
					<option value="28000">$28000</option>
				
					<option value="28500">$28500</option>
				
					<option value="29000">$29000</option>
				
					<option value="29500">$29500</option>
				
				<option value="0">$30000+</option>
			</select>
		</div>
		<div class="line">
			<label>Property Type:</label>
			<select name="structure_type">
				<option>Apartments /Condos</option>
				<option>Houses /Guest Houses</option>
				<option>Garages /Storage</option>
				<option>Commercial/Offices</option>
				<option>Lofts</option>
				<option>Hotels</option>
				<option>Other </option>
				<option>Roommates/Shares</option>
				<option>Vacations/Short-Term</option>
			</select>
		</div>
		<div class="">
			<input type="hidden" name="searchType" value="g">
			<input type="submit" class="btn_submit" value="Search" style="width:100%;" onclick="javascript:guestSearch();" />
		</div>
	</form>
	<div class="clearboth"></div>
</div> 
			<div class="rowModule areaInfo">
				
				<div class="header">About Watts</div>
				<div class="text_wrapper" style="padding:10px;">
					Watts is a small neighborhood of the City of Los Angeles in the <a href="https://www.pashutlehaskir.com/rentals/south-la-rentals/">South LA region</a>. It borders Florence-Firestone in the north, Green Meadows in the west, Willowbrook in the south, and Lynwood and South Gate in the east. Watts is extremely densely populated, mostly due to its high average household size of 4.0 (according to the LA Times). The neighborhood is fairly centrally located and easily accessible; the 105, 710, 91, and 110 freeways are all within striking distance.<br /><br />Watts is pretty much equidistant from such destinations as <a href="https://www.pashutlehaskir.com/rentals/downtown-la-rentals/">Downtown Los Angeles</a> and its burgeoning bar scene, the <a href="https://www.pashutlehaskir.com/rentals/south-bay-rentals/">South Bay</a> and its piers, and <a href="https://www.pashutlehaskir.com/rentals/culver-city-rentals/">Culver City</a> and its restaurants and night life. The area's most famous landmark is Watts Towers, a series of large metal spires that were created as a rogue, potentially illegal sculpture project and later designated as an official historical place. Apart from the aforementioned freeways, the primary arteries running through Watts are Wilmington Ave., Compton Ave., and Alameda Street.
				</div>
				
			</div> 
		
		
		<div class="rowModule">
			<div class="header">Other Rental Types</div>
			<div class="text_wrapper">				
				
					<div class="line odd"><A href="https://www.pashutlehaskir.com/bachelors/watts-bachelors/" title="watts Bachelors">Bachelors</A></div>
					
					<div class="line "><A href="https://www.pashutlehaskir.com/bungalows/watts-bungalows/" title="watts Bungalows">Bungalows</A></div>
					
					<div class="line odd"><A href="https://www.pashutlehaskir.com/condos/watts-condos/" title="watts Condos">Condos</A></div>
					
					<div class="line "><A href="https://www.pashutlehaskir.com/duplex/watts-duplex/" title="watts Duplex">Duplex</A></div>
					
					<div class="line odd"><A href="https://www.pashutlehaskir.com/fourplex/watts-fourplex/" title="watts Fourplex">Fourplex</A></div>
					
					<div class="line "><A href="https://www.pashutlehaskir.com/guesthouses/watts-guesthouses/" title="watts Guesthouses">Guesthouses</A></div>
					
					<div class="line odd"><A href="https://www.pashutlehaskir.com/houses/watts-houses/" title="watts Houses">Houses</A></div>
					
					<div class="line "><A href="https://www.pashutlehaskir.com/lofts/watts-lofts/" title="watts Lofts">Lofts</A></div>
					
					<div class="line odd"><A href="https://www.pashutlehaskir.com/petfriendly/watts-petfriendly/" title="watts Petfriendly">Petfriendly</A></div>
					
					<div class="line "><A href="https://www.pashutlehaskir.com/singles/watts-singles/" title="watts Singles">Singles</A></div>
					
					<div class="line odd"><A href="https://www.pashutlehaskir.com/storage/watts-storage/" title="watts Storage">Storage</A></div>
					
					<div class="line "><A href="https://www.pashutlehaskir.com/studios/watts-studios/" title="watts Studios">Studios</A></div>
					
					<div class="line odd"><A href="https://www.pashutlehaskir.com/townhouses/watts-townhouses/" title="watts Townhouses">Townhouses</A></div>
					
					<div class="line "><A href="https://www.pashutlehaskir.com/triplex/watts-triplex/" title="watts Triplex">Triplex</A></div>
										
			</div>
		</div>
		

		<div class="rowModule">
			<div class="header">Nearby Areas</div>
			<div class="text_wrapper">				
				 

					<div class="line odd">
						<a href="../usc-apartments/usc-apartments.html" title="USC">USC</a>
					</div>
						
					 

					<div class="line ">
						<a href="../artesia-apartments/artesia-apartments.html" title="Artesia">Artesia</a>
					</div>
						
					 

					<div class="line odd">
						<a href="../bell-apartments/bell-apartments.html" title="Bell">Bell</a>
					</div>
						
					 

					<div class="line ">
						<a href="../bellflower-apartments/bellflower-apartments.html" title="Bellflower">Bellflower</a>
					</div>
						
					 

					<div class="line odd">
						<a href="../central-la-apartments/central-la-apartments.html" title="Central LA">Central LA</a>
					</div>
						
					 

					<div class="line ">
						<a href="../chinatown-apartments/chinatown-apartments.html" title="Chinatown">Chinatown</a>
					</div>
						
					 

					<div class="line odd">
						<a href="../downtown-la-apartments/downtown-la-apartments.html" title="Downtown LA">Downtown LA</a>
					</div>
						
					 

					<div class="line ">
						<a href="../bell-gardens-apartments/bell-gardens-apartments.html" title="Bell Gardens">Bell Gardens</a>
					</div>
						
					 

					<div class="line odd">
						<a href="../commerce-apartments/commerce-apartments.html" title="Commerce">Commerce</a>
					</div>
						
					 

					<div class="line ">
						<a href="../cerritos-apartments/cerritos-apartments.html" title="Cerritos">Cerritos</a>
					</div>
						
					 

					<div class="line odd">
						<a href="../compton-apartments/compton-apartments.html" title="Compton">Compton</a>
					</div>
						
					 

					<div class="line ">
						<a href="../downey-apartments/downey-apartments.html" title="Downey">Downey</a>
					</div>
						
					 

					<div class="line odd">
						<a href="../boyle-heights-apartments/boyle-heights-apartments.html" title="Boyle Heights">Boyle Heights</a>
					</div>
						
					 

					<div class="line ">
						<a href="../los-angeles-apartments/los-angeles-apartments.html" title="Los Angeles">Los Angeles</a>
					</div>
						
					 

					<div class="line odd">
						<a href="../city-terrace-apartments/city-terrace-apartments.html" title="City Terrace">City Terrace</a>
					</div>
						
					 

					<div class="line ">
						<a href="../hawaiian-gardens-apartments/hawaiian-gardens-apartments.html" title="Hawaiian Gardens">Hawaiian Gardens</a>
					</div>
						
					 

					<div class="line odd">
						<a href="../huntington-park-apartments/huntington-park-apartments.html" title="Huntington Park">Huntington Park</a>
					</div>
						
					 

					<div class="line ">
						<a href="../la-mirada-apartments/la-mirada-apartments.html" title="La Mirada">La Mirada</a>
					</div>
						
					 

					<div class="line odd">
						<a href="../south-la-apartments/south-la-apartments.html" title="South LA">South LA</a>
					</div>
						
					 

					<div class="line ">
						<a href="../leimert-park-apartments/leimert-park-apartments.html" title="Leimert Park">Leimert Park</a>
					</div>
						
					 

					<div class="line odd">
						<a href="../west-adams-apartments/west-adams-apartments.html" title="West Adams">West Adams</a>
					</div>
						
					 

					<div class="line ">
						<a href="../el-sereno-apartments/el-sereno-apartments.html" title="El Sereno">El Sereno</a>
					</div>
						
					 

					<div class="line odd">
						<a href="../lynwood-apartments/lynwood-apartments.html" title="Lynwood">Lynwood</a>
					</div>
						
					 

					<div class="line ">
						<a href="../norwalk-apartments/norwalk-apartments.html" title="Norwalk">Norwalk</a>
					</div>
						
					 

					<div class="line odd">
						<a href="../paramount-apartments/paramount-apartments.html" title="Paramount">Paramount</a>
					</div>
						
					 

					<div class="line ">
						<a href="../pico-rivera-apartments/pico-rivera-apartments.html" title="Pico Rivera">Pico Rivera</a>
					</div>
						
					 

					<div class="line odd">
						<a href="../santa-fe-springs-apartments/santa-fe-springs-apartments.html" title="Santa Fe Springs">Santa Fe Springs</a>
					</div>
						
					 

					<div class="line ">
						<a href="../lincoln-heights-apartments/lincoln-heights-apartments.html" title="Lincoln Heights">Lincoln Heights</a>
					</div>
						
					 

					<div class="line odd">
						<a href="../south-gate-apartments/south-gate-apartments.html" title="South Gate">South Gate</a>
					</div>
						
					 

					<div class="line ">
						<a href="watts-apartments.html" title="Watts">Watts</a>
					</div>
						
					 

					<div class="line odd">
						<a href="../westmont-apartments/westmont-apartments.html" title="Westmont">Westmont</a>
					</div>
						
					 

					<div class="line ">
						<a href="../whittier-apartments/whittier-apartments.html" title="Whittier">Whittier</a>
					</div>
						
					 

					<div class="line odd">
						<a href="../willow-brook-apartments/willow-brook-apartments.html" title="Willow Brook">Willow Brook</a>
					</div>
						
					
					
			</div>
		</div>
		
		

		<div class="rowModule">
			<div class="header">Popular Areas</div>
			<div class="text_wrapper">				
				

							<div class="line odd">
								<a href="../los-angeles-apartments/los-angeles-apartments.html" title="Los Angeles">Los Angeles</a>
							</div>

						

							<div class="line ">
								<a href="../westside-apartments/westside-apartments.html" title="Westside">Westside</a>
							</div>

						

							<div class="line odd">
								<a href="../san-fernando-valley-apartments/san-fernando-valley-apartments.html" title="San Fernando Valley">San Fernando Valley</a>
							</div>

						

							<div class="line ">
								<a href="../south-bay-apartments/south-bay-apartments.html" title="South Bay">South Bay</a>
							</div>

						

							<div class="line odd">
								<a href="../orange-county-apartments/orange-county-apartments.html" title="Orange County">Orange County</a>
							</div>

						

							<div class="line ">
								<a href="../san-gabriel-valley-apartments/san-gabriel-valley-apartments.html" title="San Gabriel Valley">San Gabriel Valley</a>
							</div>

						

							<div class="line odd">
								<a href="../san-diego-apartments/san-diego-apartments.html" title="San Diego">San Diego</a>
							</div>

						

							<div class="line ">
								<a href="../santa-barbara-apartments/santa-barbara-apartments.html" title="Santa Barbara">Santa Barbara</a>
							</div>

						
					
			</div>
		</div>
		
		
		
	</div>
	<div class="clearfix"></div>

	
</div>

</div> <!-- End main container div -->
	
	<!-- FOOTER -->
	<?php
		include('footer.php');
	?>
	
		
		 
	
	
	<!-- Bootstrap core JavaScript
	
	<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery.min.js"></script>
	

	
	<script src="js/new/jquery-ui-1.10.4/jquery-ui-1.10.4.js"></script>
	<script src="js/new/jquery.cycle.all.js"></script>
	
	<!-- Latest compiled and minified JavaScript -->
	<script src="js/bootstrap.min.js"></script>
	
	
			
	<script src="js/fb_login.js"></script>	
	<script src="js/navigation/menu.js" type="text/javascript" language="javascript"></script>	
	<script src="js/default.js" type="text/javascript" language="javascript"></script>	

	<script src="js/ddaaccordion.js" type="text/javascript" language="javascript"></script>


	
	<!-- Default JavaScript -->
	<script src="js/new/default.js"></script>
			<div id="overDiv" style="position:absolute; visibility:hide;z-index:1;"></div>
		
	
	<!-- Pretty photo --->
	<link rel="stylesheet" href="../../js/new/prettyphoto/css/prettyPhoto.css" type="text/css" media="screen" charset="utf-8" />
	<script src="../../js/new/prettyphoto/js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>
	
	
	
			
			
				

	 
	<div id="ttdUniversalPixelTagfb79dc7af6cc4733a9c4a87c68c6f55e" style="display:none">
        <script src="https://js.adsrvr.org/up_loader.1.1.0.js" type="text/javascript"></script>
        <script type="text/javascript">
            (function(global) {
                if (typeof TTDUniversalPixelApi === 'function') {
                    var universalPixelApi = new TTDUniversalPixelApi();
                    universalPixelApi.init("nalbr2d", ["k56d7yb"], "https://insight.adsrvr.org/track/up", "ttdUniversalPixelTagfb79dc7af6cc4733a9c4a87c68c6f55e");
                }
            })(this);
        </script>
    </div>

<img src="https://my.renttrack.com/bundles/rjpublic/images/af.png?af=WESTSIDE"> 
			
	</body>
</html>



<script>
	$('.areaInfo .text_wrapper').readmore({
	  speed: 75,
	  maxHeight: 210
	});
</script>



form.area_id 340 <br />
form.region_id 0 <br />
bedroom_type 1,2,3,4,5,6,7,10,8,9,10,11,12,13<br />
property_type 7,8,9,10,11,12,13,16,19,20,21<br />
totalresults 5000<br />
