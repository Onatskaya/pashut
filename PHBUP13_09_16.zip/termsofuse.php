<?php

include_once('functions/function.php');
if($_SESSION['language']=='Hebrew')
{
	echo "<script>location.href='termsofuse_h.php'</script>";
}
?>
	
	 
    <!DOCTYPE HTML> 
<html lang="en">
  <head>

  	
 
		
				<title>pashutlehaskir.com</title>
				<link rel="shortcut icon" href="" />
				<meta charset="utf-8">
				<meta http-equiv="X-UA-Compatible" content="IE=edge">
				
				<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, width=device-width">
				<meta http-equiv="expires" content="0" />
				<meta http-equiv="Pragma" content="no-cache" />
				<meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8" />

				
       			<meta name="apple-itunes-app" content="app-id=509021914">
   				

				
				<script type="text/javascript">
setTimeout(function(){var a=document.createElement("script");
var b=document.getElementsByTagName("script")[0];
a.src=document.location.protocol+"//script.crazyegg.com/pages/scripts/0044/7420.js?"+Math.floor(new Date().getTime()/3600000);
a.async=true;a.type="text/javascript";b.parentNode.insertBefore(a,b)}, 1);
</script>

<script>
var _prum = [['id', '56a93ecdabe53ddd5a18ddad'],
             ['mark', 'firstbyte', (new Date()).getTime()]];
(function() {
    var s = document.getElementsByTagName('script')[0]
      , p = document.createElement('script');
    p.async = 'async';
    p.src = '//rum-static.pingdom.net/prum.min.js';
    s.parentNode.insertBefore(p, s);
})();
</script> 

			<script type="text/javascript">
			function movetoNext(current, nextFieldID) {
			if (current.value.length >= current.maxLength) {
			document.getElementById(nextFieldID).focus();
			}
			}
			</script>
			 <!-- Google Fonts embed code -->
			<script type="text/javascript">
				(function() {
					var link_element = document.createElement("link"),
						s = document.getElementsByTagName("script")[0];
					if (window.location.protocol !== "http:" && window.location.protocol !== "https:") {
						link_element.href = "http:";
					}
					link_element.href += "//fonts.googleapis.com/css?family=Lato:100italic,100,300italic,300,400italic,400,700italic,700,900italic,900";
					link_element.rel = "stylesheet";
					link_element.type = "text/css";
					s.parentNode.insertBefore(link_element, s);
				})();
			</script>




						
				<!-- Latest compiled and minified CSS -->
				<link href="css/201603/ui-lightness/jquery-ui-1.10.4.css" rel="stylesheet">
				<link rel="stylesheet" href="css/bootstrap.min.css">
				<!-- Custom styles for this template -->
				<link href="css/201603/global.css" rel="stylesheet">
				<link href="css/201603/section.css" rel="stylesheet">
				<link href="css/201603/carousel.css" rel="stylesheet">
			
					<meta name="keywords" content="pashutlehaskir.com | Rent SoCal Houses, Apartments & More, Los Angeles rentals, Santa Monica House, South Bay Rentals, Los Angeles Apartments, Orange County Rentals, San Diego Apartments, Hermosa Beach Apartments, Hollywood For Rent, Burbank Apartments, Glendale Homes, Studio City Rentals, Apartments for Rent, Houses for Rent, Condos for Rent, Apartments in Los Angeles, Apartments in LA, USC, University of Southern California, Cal State, California State University, UCLA, University of California, University of California Los Angeles, Loyola Marymount University, Pepperdine, Pepperdine University, USC Student Housing, USC Housing, USC Apartments, Cal State Housing, Cal State Student Housing, Cal State Apartments, UCLA Housing, UCLA Student Housing, UCLA Apartments, LMU Housing, LMU Student Housing, LMU Apartments, Pepperdine Housing, Pepperdine Student Housing, Pepperdine Apartments" />
				
					<meta name="description" content="pashutlehaskir.com is the #1 home finding service in the Los Angeles area. Search SoCal apartment rentals, houses, condos & roommates!" />
				
					<meta name="robots" content="index,follow" />
					<meta name="GOOGLEBOT" content="index,follow" />
				
			
			
			<meta name="google-translate-customization" content="954d153704cc37f5-fac58c9bb4d3c842-g115d03cfb1ac5d23-17"></meta>
			
			
        
	</head>

	
	<body  class="guest" >
	
	

	
		
		<div id="slidedown-content" data-status="hide" class="none">
			<div id="login-content" class="fb">
				<form action="login.php" name="loginForm" method="post">
					<span>
						<label>Username</label> 
						<input type="text" name="username" class="text" size="10" maxlength="100" />
					</span>
					<span>
						<label>Password</label>
						<input type="password" autocomplete="off" class="text" name="password" size="10" maxlength="45" />
					</span>	

					
					<input type="image" name="login" class="submit" src="images/new/btn-login.png" align="absmiddle" />
					
					

				</form>
				<div class="separator">
				-------------- OR --------------
				</div>
				<div class="fb-login-section">
				<a href="#" class="fb-login"><img src="images/fblogin.png"></a>
				</div>
			</div>		
		</div>
	
		<?php
		include('header.php');
		?>
	
	
    <!-- Carousel
    ================================================== -->
	<div class="container">

<div class="oneColumnLayout static-page">
	

	<div class="col-md-12 term_of">

		<h1>Terms of Use - Members</h1>
		By using the pashutlehaskir.com website (the "Web site") you signify that you have read, understand and agree to be bound by these Terms of Use. We reserve the right, at our sole discretion, to change, modify, add, or delete portions of these Terms of Use at any time without further notice. If we do this, we will post the changes to these Terms of Use on this page and will indicate at the top of this page the Terms of Use's effective date. Your continued use of the Web site after any such changes constitutes your acceptance of the new Terms of Use. If you do not agree to abide by these or any future Terms of Use, please do not use or access Web site. It is your responsibility to regularly review these Terms of Use. 
		
		<br/><h2>IP Usage Rules</h2>
	For renter/tenant memberships, IP usage can not exceed 10 IP addresses in a 30 day period.  For a single membership usage of the mobile app may not exceed 2 simultaneous sessions.
		
		<br/><h2>Membership</h2>
		Single membership for renters costs NIS99.00 (30-Day Single Membership) plus an additional 25% finders fee of the monthly rent of the property., the receipt of which is hereby acknowledged. It is agreed that this constitutes full and complete payment for services described in this contract. PashutLeHaskir., DBA: pashutlehaskir.com Properties is licensed in the State of Israel with headquarters in Tel Aviv; and in the business of supplying prospective tenants with listings of residential real properties for tenancy. Company agrees to make available to Client via the Internet, listings obtained by Company of residential units available for rental. It is agreed by both Company and Client that only the named Client is entitled to the service provided by Company. Company does not represent or act as an agent on behalf of the owner(s) of the properties listed and made available to the Client. Company does not guarantee the accuracy of information provided by owners, managers, agents, or representatives of any residential unit listed by Company and made available to Client as to said property listed. Company promises, however, to make every good faith effort feasible to ensure the accuracy of information provided to Client. Company does not promise Client that Client will enter into agreement with any owner of any property listed by Company for the rental of any residential unit. It is agreed by both Client and Company that the service provided by Company to Client is limited to providing information to Client as to residential units reasonably believed to be available for rental. Company promises to make every good faith effort feasible to ensure that only current and up-to-date listings are provided to Client. 
		
		<br/><h2>Confidentiality & Usage</h2>
		The purchaser of rental information from pashutlehaskir.com agrees to keep the information absolutely confidential and not to share or disclose the information or login username and password with any person or entity for any purpose. The purchaser will use the information for the purposes of locating housing for their individual and personal use and will not use the information for any corporate purpose including, but not limited to, soliciting property management, scraping listings, and real estate investment business without the written consent of pashutlehaskir.com. The purchaser of the information further agrees that the information is proprietary to pashutlehaskir.com and that any misuse of the information is a breach of this agreement as well as a violation of law in Israel governing trade secrets; misuse is subject to prosecution by government authorities and monetary recovery of damages by pashutlehaskir.com. pashutlehaskir.com maintains the right to suspend, disable or terminate any purchaser account for suspicious usage activity, including concurrent login sessions, group usage, usage from a range or variety of IP addresses, suspected non-personal use, corporate use as well as abnormally high usage levels. pashutlehaskir.com is the exclusive arbiter of types of usage that is deemed to be suspicious and warrants account suspension, disablement, or termination. 
		
		<br/><h2>Accuracy of Information</h2>
		pashutlehaskir.com makes an honest and diligent effort to acquire accurate information furnished by the landlords or property agents. The greater portion of PashutLeHaskir.com’s information is obtained by use of telephone; therefore, our representation and description of rentals will reflect the information given to us by the landlord or property agent. Accordingly we cannot be responsible for the accuracy of property descriptions or conditions but ensure and attempt to provide accuracy by our verification process . Due to the nature of the real estate market, all listings are subject to prior rental. 
		
		<br/><h2>Housing Laws</h2>
		All vacancy listing submissions are subject to Israel housing laws which make it illegal to indicate in any advertisement any preference, limitation, or discrimination because of race, color, religion, sex, physical or mental disability, familial status (e.g. "No children" or "Not suitable for Children"), sexual orientation, ancestry, marital status, or source of income (e.g. "No Section 8" is prohibited). Your local jurisdiction may impose additional requirements.
		
		
		<br/><h2>Contract and Receipt</h2>
		Clients that join the service will have tendered to pashutlehaskir.com, herein known as Company, a fee for membership. At the time of sign-up the client agreed to a Contract using a binding digital signature. It is agreed that this Contract constitutes full and complete payment for services described in this contract. pashutlehaskir.com is a prepaid information and rental listing service licensed in the business of supplying prospective tenants with listings for residential real estate properties for tenancy. Company agrees to make available to Client via the Internet, listings obtained by Company of residential units available for rental. It is agreed by both Company and Client that only the named Client is entitled to the service provided by Company. Company does not represent or act as agent on behalf of the owner(s) of the properties listed and made available to the Client. Company does not guarantee the accuracy of information provided by owners, managers, agents, or representatives of any residential unit listed by Company and made available to Client as to said property listed. Company promises, however, to make every good faith effort feasible to ensure the accuracy of information provided to Client. Company does not promise Client that Client will enter into agreement with any owner of any property listed by Company for the rental of any residential unit. It is agreed by both Client and Company that the service provided by Company to Client is limited to providing information to Client as to residential units reasonably believed to be available for rental. Company promises to make every good faith effort feasible to ensure that only current and up-to-date listings are provided to Client. 
		
		<br/><h2>Right to Refund</h2>
		Membership refunds are conducted on a case by case basis. Please contact our offices by email for refund procedures and information. 


		<br/><h2>User Conduct</h2>
		Purchasers shall have the capability to post interactive content such as photos and video, as well as messages to landlords and property agents while using the service. Purchasers agree to not post or transmit any unlawful, threatening, abusive, libelous, defamatory, obscene, vulgar, pornographic, profane, or indecent information of any kind, including without limitation any transmissions constituting or encouraging conduct that would constitute a criminal offense, give rise to civil liability or otherwise violate any local, state, national, or international law; agree to not post or transmit any information, software, or other material which violates or infringes in the rights of others, including material which is an invasion of privacy or publicity rights or which is protected by copyright, trademark or other proprietary right, or derivative works with respect thereto, without first obtaining permission from the owner or right holder; agrees to not disrupt the normal flow of communication in the pashutlehaskir.com messaging areas; agrees to not claim a relationship with or to speak for any business, association, institution or other organization for which the Purchasers is not authorized to claim such a relationship. 

		<br/><h2>Accepted Method of Payment</h2>

		Credit Card, Debit Card, and Paypal. 

		<br/><h2>Terms of Use – Landlords, Property Owners & Roommates</h2>

		<br/><h2>Introduction</h2>
		Welcome to pashutlehaskir.com, an online service connecting landlords, roommates and renters. The pashutlehaskir.com service is operated by pashutlehaskir.com network ("pashutlehaskir.com"). By using the pashutlehaskir.com web site (the "Web site") you signify that you have read, understand and agree to be bound by these Terms of Use (this "Agreement"). We reserve the right, at our sole discretion, to change, modify, add, or delete portions of these Terms of Use at any time without further notice. If we do this, we will post the changes to these Terms of Use on this page and will indicate at the top of this page the Terms of Use's effective date. Your continued use of the Web site after any such changes constitutes your acceptance of the new Terms of Use. If you do not agree to abide by these or any future Terms of Use, please do not use or access Web site. It is your responsibility to regularly review these Terms of Use. 
		
		<br/><h2>Eligibility</h2>
		By using the Web site, you represent and warrant that you have the right, authority, and capacity to agree to and to abide by all of the terms and conditions of this Agreement. pashutlehaskir.com may terminate your account for any reason, at any time. 

		<br/><h2>User Conduct</h2>
	
       You understand that the Web site is available for the specific uses of advertising vacancies and communicating with prospective tenants. You agree that no materials of any kind submitted through your account will violate or infringe upon the rights of any third party, including copyright, trademark, privacy or other personal or proprietary rights; or contain libelous, defamatory or otherwise unlawful material. You further agree not to harvest or collect email addresses or other contact information of members from the Web site by electronic or other means for the purposes of sending unsolicited emails or other unsolicited communications. Additionally, you agree not to use automated scripts to collect information from the Web site or for any other purpose. You further agree that you may not use Web site in any unlawful manner or in any other manner that could damage, disable, overburden or impair Web site. In addition, you agree not to use the Web site to: 
       <ul>
       	<li>upload, post, email, transmit or otherwise make available any content that we deem to be harmful, threatening, abusive, harassing, vulgar, obscene, hateful, or racially, ethnically or otherwise objectionable; </li>
       	<li>impersonate any person or entity, or falsely state or otherwise misrepresent yourself or your affiliation with any person or entity; </li>
       	<li>upload, post, email, transmit or otherwise make available any unsolicited or unauthorized advertising, promotional materials, "junk mail," "spam," "chain letters," "pyramid schemes," or any other form of solicitation; </li>
       	<li>upload, post, email, transmit or otherwise make available any material that contains software viruses or any other computer code, files or programs designed to interrupt, destroy or limit the functionality of any computer software or hardware or telecommunications equipment; </li>
       	<li>intimidate or harass another; </li>
       	<li>use or attempt to use another's account, service or system without authorization from Web site, or create a false identity on this website.</li>
       </ul>

       <br/><h2>Proprietary Rights in Content on pashutlehaskir.com</h2>
       All content on Web site, including but not limited to design, text, graphics, other files, and their selection and arrangement (the "Content"), are the proprietary property of pashutlehaskir.com or its licensors. All rights reserved. The Content may not be modified, copied, distributed, framed, reproduced, republished, downloaded, displayed, posted, transmitted, or sold in any form or by any means, in whole or in part, without Web site's prior written permission. You may download or print a copy of any portion of the Content solely for your personal, non-commercial use, provided that you keep all copyright or other proprietary notices intact. You may not republish Content on any Internet, Intranet or Extranet site or incorporate the information in any other database or compilation. Any other use of the Content is strictly prohibited. All trademarks, logos, trade dress and service marks on the Web site are either trademarks or registered trademarks of pashutlehaskir.com or its licensors and may not be copied, imitated, or used, in whole or in part, without the prior written permission of pashutlehaskir.com. 

       <br/><h2>Member Content Posted on the Site</h2>
       You are solely responsible for the content, photos or Content that you publish or display (hereinafter, "post") on the Service, or transmit to other users of the service (collectively the "Member Content"). You understand and agree that pashutlehaskir.com may review and delete or remove any Content that in the sole judgment of pashutlehaskir.com violate this Agreement or which might be offensive, illegal, or that might violate the rights, harm, or threaten the safety of Members. By posting Content to any part of the Web site, you automatically grant, and you represent and warrant that you have the right to grant, to pashutlehaskir.com an irrevocable, perpetual, non-exclusive, transferable, fully paid, worldwide license (with the right to sublicense) to use, copy, perform, display, reformat, translate, excerpt (in whole or in part) and distribute such information and content and to prepare derivative works of, or incorporate into other works, such information and content, and to grant and authorize sublicenses of the foregoing.

       <br/><h2>Copyright Policy</h2>
       pashutlehaskir.com respects the intellectual property rights of others. If you believe your work has been copied in a way that constitutes copyright infringement or are aware of any infringing material on the Web site, please contact us at info@pashutlehaskir.com.com and provide us with the following information: an electronic or physical signature of the person authorized to act on behalf of the owner of the copyright interest; a description of the copyrighted work that you claim has been infringed; a description of where the material that you claim is infringing is located on the Web site; your address, telephone number, and email address; a written statement by you that you have a good faith belief that the disputed use is not authorized by the copyright owner, its agent, or the law; a statement by you, made under penalty of perjury, that the above information in your notice is accurate and that you are the copyright owner or authorized to act on the copyright owner's behalf. 

       <br/><h2>Links to other websites</h2>
       The Web site contains links to other web sites. pashutlehaskir.com is not responsible for the content, accuracy or opinions express in such web sites, and such web sites are not investigated, monitored or checked for accuracy or completeness by us. Inclusion of any linked web site on pashutlehaskir.com Web site does not imply approval or endorsement of the linked web site by pashutlehaskir.com. If you decide to leave pashutlehaskir.com Web site and access these third-party sites, you do so at your own risk. 

       <br/><h2>User Disputes</h2>
       You are solely responsible for your interactions with other pashutlehaskir.com Users. pashutlehaskir.com reserves the right, but has no obligation, to monitor disputes between you and other Users. 

       <br/><h2>Privacy</h2>
       pashutlehaskir.com cares about the privacy of its members. Our privacy policy is available throughout the website. 
       <br/><h2>Disclaimers</h2>
      <p> pashutlehaskir.com is not responsible for any incorrect or inaccurate Content posted on the Web site or in connection with the Service, whether caused by users of the Web site, or by any of the equipment or programming associated with or utilized in the Service. pashutlehaskir.com is not responsible for the conduct, whether online or offline, of any user of the Web site or Member of the Service. The Service may be temporarily unavailable from time to time for maintenance or other reasons. pashutlehaskir.com assumes no responsibility for any error, omission, interruption, deletion, defect, delay in operation or transmission, communications line failure, theft or destruction or unauthorized access to, or alteration of, user or Member communications. pashutlehaskir.com is not responsible for any problems or technical malfunction of any telephone network or lines, computer online systems, servers or providers, computer equipment, software, failure of email or players on account of technical problems or traffic congestion on the Internet or at any web site or combination thereof, including injury or damage to users and/or Members or to any other person's computer related to or resulting from participating or downloading materials in connection with the Web and/or in connection with the Service. Under no circumstances will pashutlehaskir.com be responsible for any loss or damage, including personal injury or death, resulting from anyone's use of the Web site or the Service, any Content posted on the Web site or transmitted to Members, or any interactions between users of the Web site, whether online or offline. THE WEB SITE, THE SERVICE AND THE CONTENT ARE PROVIDED "AS-IS" AND pashutlehaskir.com DISCLAIMS ANY AND ALL WARRANTIES, WHETHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION IMPLIED WARRANTIES OF TITLE, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT. pashutlehaskir.com CANNOT GUARANTEE AND DOES NOT PROMISE ANY SPECIFIC RESULTS FROM USE OF THE WEB SITE AND/OR THE SERVICE. </p>

       <h2>Limitation on Liability</h2>
       <p>EXCEPT IN JURISDICTIONS WHERE SUCH PROVISIONS ARE RESTRICTED, IN NO EVENT WILL pashutlehaskir.com BE LIABLE TO YOU OR ANY THIRD PERSON FOR ANY INDIRECT, CONSEQUENTIAL, EXEMPLARY, INCIDENTAL, SPECIAL OR PUNITIVE DAMAGES, INCLUDING ALSO LOST PROFITS ARISING FROM YOUR USE OF THE WEB SITE OR THE SERVICE, EVEN IF pashutlehaskir.com HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. NOTWITHSTANDING ANYTHING TO THE CONTRARY CONTAINED HEREIN, pashutlehaskir.com'S LIABILITY TO YOU FOR ANY CAUSE WHATSOEVER, AND REGARDLESS OF THE FORM OF THE ACTION, WILL AT ALL TIMES BE LIMITED TO THE AMOUNT PAID, IF ANY, BY YOU TO pashutlehaskir.com FOR THE SERVICE DURING THE TERM OF MEMBERSHIP. </p>

       <h2>Governing Law and Venue</h2>
       If there is any dispute about or involving the Web site and/or the Service, you agree that the dispute will be governed by the laws of the State of Israel without regard to its conflict of law provisions. You also agree to the exclusive jurisdiction and venue of the courts of the state of Israel and waive all defenses of lack of personal jurisdiction and forum non conveniens. Any cause of action by you with respect to the Web site and/or the Service must be instituted within one (1) year after the cause of action arose or be forever waived and barred.

       <br/><h2>Indemnity</h2>
       You agree to indemnify and hold pashutlehaskir.com, its subsidiaries, affiliates, officers, agents, and other partners and employees, harmless from any loss, liability, claim, or demand, including reasonable attorney's fees, made by any third party due to or arising out of your use of the Service in violation of this Agreement or your violation of any law or the rights of a third party. 

        <br/><h2>Other</h2>
        These Terms of Use constitute the entire agreement between you and pashutlehaskir.com regarding the use of the Web site and/or the Service, superseding any prior agreements between you and pashutlehaskir.com relating to your use of the Web site or the Service. The failure of pashutlehaskir.com to exercise or enforce any right or provision of these Terms of Use shall not constitute a waiver of such right or provision. If any provision of this Agreement is held invalid, the remainder of this Agreement shall continue in full force and effect.




		
		<br/><h2>Questions</h2>
		Please contact us with any questions regarding this agreement. 
		
		
		<a href="javascript:history.back()">Previous Page</a>
	</div>
</div>

</div> <!-- End main container div -->
	
	
		<!-- FOOTER -->
	<?php
		include('footer.php');
	?>
	
		
		
	
	
	<!-- Bootstrap core JavaScript
	================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	
<script src="js/jquery.min.js"></script>
	

	
	<script src="js/new/jquery-ui-1.10.4/jquery-ui-1.10.4.js"></script>
	<script src="js/new/jquery.cycle.all.js"></script>
	
	<!-- Latest compiled and minified JavaScript -->
	<script src="js/bootstrap.min.js"></script>
	
	
			
	<script src="js/fb_login.js"></script>	
	<script src="js/navigation/menu.js" type="text/javascript" language="javascript"></script>	
	<script src="js/default.js" type="text/javascript" language="javascript"></script>	

	<script src="js/ddaaccordion.js" type="text/javascript" language="javascript"></script>


	
	<!-- Default JavaScript -->
	<script src="js/new/default.js"></script>
	
	<!-- Pretty photo --->
	<link rel="stylesheet" href="../js/new/prettyphoto/css/prettyPhoto.css" type="text/css" media="screen" charset="utf-8" />
	<script src="../js/new/prettyphoto/js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>
	
	
	<script src="../js/tooltips/wz_tooltip.js" type="text/javascript" language="javascript"></script>
			
			
				


		
	<div id="ttdUniversalPixelTagfb79dc7af6cc4733a9c4a87c68c6f55e" style="display:none">
	        <script src="https://js.adsrvr.org/up_loader.1.1.0.js" type="text/javascript"></script>
	        <script type="text/javascript">
	            (function(global) {
	                if (typeof TTDUniversalPixelApi === 'function') {
	                    var universalPixelApi = new TTDUniversalPixelApi();
	                    universalPixelApi.init("nalbr2d", ["k56d7yb"], "https://insight.adsrvr.org/track/up", "ttdUniversalPixelTagfb79dc7af6cc4733a9c4a87c68c6f55e");
	                }
	            })(this);
	        </script>
	    </div>


	 
			
			
	</body>
</html>

